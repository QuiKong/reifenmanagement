<?php
include "includes\connection.php";
?>
<?php
  $con = mysqli_connect("localhost","root","","charts");
  if($con){
    echo "connected";
  }
?>

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    
    <script type="text/javascript">
      
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Art', 'Anzahl'],
         <?php
         $sql = "SELECT * FROM Kntengint";
         $fire = mysqli_query($con,$sql);
          while ($result = mysqli_fetch_assoc($fire)) {
            echo"['".$result['Art']."',".$result['Anzahl']."],";
          }

         ?>
        ]);

        var options = {
          title: 'Kontenginten der Reifensätze '
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
  
    <div id="piechart" style="width: 900px; height: 500px;"></div>
 
