<?php


$Reifensatz = $_POST['Reifensatz'];
$Reifenplatz1 = $_POST['Reifenplatz1'];
$Reifenart1 = $_POST['Reifenart1'];
$Mischung1= $_POST['Mischung1'];
$Bearbeitungsvarianten1 = $_POST['Bearbeitungsvarianten1'];
$Zieldruck1 = $_POST['Zieldruck1'];



$Reifenplatz2 = $_POST['Reifenplatz2'];
$Reifenart2 = $_POST['Reifenart2'];
$Mischung2 = $_POST['Mischung2'];
$Bearbeitungsvarianten2 = $_POST['Bearbeitungsvarianten2'];
$Zieldruck2 = $_POST['Zieldruck2'];




$Reifenplatz3 = $_POST['Reifenplatz3'];
$Reifenart3 = $_POST['Reifenart3'];
$Mischung3 = $_POST['Mischung3'];
$Bearbeitungsvarianten3 = $_POST['Bearbeitungsvarianten3'];
$Zieldruck3 = $_POST['Zieldruck3'];



$Reifenplatz4 = $_POST['Reifenplatz4'];
$Reifenart4 = $_POST['Reifenart4'];
$Mischung4 = $_POST['Mischung4'];
$Bearbeitungsvarianten4 = $_POST['Bearbeitungsvarianten4'];
$Zieldruck4 = $_POST['Zieldruck4'];






require 'connection.php'; //Referenz auf die Connection damit die Datenbankverbindung aufgebaut wird.


//Erstellen des SQL Ausdruck. Dieser wird in $SQL gespeichert.

$sql1 ="INSERT INTO `reifen2` (`Position`, `Art`, `Mischung`, `Spezifikation`,`Zieldruck`,`Reifensatz`,`Status`)
 VALUES
 ('$Reifenplatz1', '$Reifenart1', '$Mischung1', '$Bearbeitungsvarianten1','$Zieldruck1','$Reifensatz',1),('$Reifenplatz2', '$Reifenart2', '$Mischung2', '$Bearbeitungsvarianten2','$Zieldruck2','$Reifensatz',1),('$Reifenplatz3', '$Reifenart3', '$Mischung3', '$Bearbeitungsvarianten3','$Zieldruck3','$Reifensatz',1),('$Reifenplatz4', '$Reifenart4', '$Mischung4', '$Bearbeitungsvarianten4','$Zieldruck4','$Reifensatz',1)";


//Ausführen des SQL-Befehls. Bei Erfolg kommt die untenstehende Meldung. Ansonsten eine Fehlermeldung.
$ergebnis = $con->query($sql1) 
    or die($con->error);

    header('location: thank_page.php');

//Die Datenbankverbindung wird wieder getrennt.

mysqli_close($con);

?>
