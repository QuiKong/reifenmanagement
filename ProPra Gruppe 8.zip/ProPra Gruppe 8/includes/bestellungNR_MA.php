<!DOCTYPE html>
<html lang="de-DE">
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../assets/css/pages.css">
    <link rel="stylesheet" href="../assets/css/thank_page.css">
    <link rel="stylesheet" href="../assets/css/timer.css">
    <script type="text/javascript" src="../assets/js/script.js"></script>
    </head>

    <body>
        <div class="navbar">

            <div class="menu">
            <input type="hidden" data-time="300" class="time-set" />
            <a class="tablinks" id="timer_left"  style="float: left;">00:00</a>
            <a class="end_time"></a>
            <a class="tablinks" onclick="opentab(event, 'Einstellung')">Einstellung </a>
            <a class="tablinks" onclick="window.location.href='abmelden.php';"> Logout</a>
            </div>
        </div>
        
<table class="table">
  <tr>
      <td>Reifensatz</td>
      <td>Position</td>
      <td>Reifenart</td>
      <td>Mischung</td>
      <td>Bearbeitungsvarianten</td>
      <td>Zieldruck</td>
  </tr>

<?php
  require 'connection.php'; 
  if(isset($_POST['save_select'])){
  $reifensatz = $_POST['Reifensatz'];

  $stmt2 = "SELECT * FROM reifen2 WHERE `Reifensatz` = $reifensatz" ;
  $result2 = $con->query($stmt2);

  if($result2->num_rows > 0){

  while( $row2 = $result2->fetch_assoc()){
?>

  <tr>
    <td id="Reifensatz"><?php echo $row2['Reifensatz'];?></td>
    <td id="Position"><?php echo $row2['Position'];?></td>
    <td id="Art"><?php echo $row2['Art'];?></td>
    <td id="Mischung"><?php echo $row2['Mischung'];?></td>
    <td id="Bearbeitungsvarianten"><?php echo $row2['Spezifikation'];?></td>
    <td id="Zieldruck"><?php echo $row2['Zieldruck'];?></td>
</tr>
<?php
} 
}  
}
?> 
</table>
        <br>
        <br>
        <a class="btn-block2" href="../mitarbeiter.php">Zurück</a>
</body>
</html>