<?php 

$time = $_POST['time']; 
$driver = $_POST['driver']; 
$menge= $_POST['menge']; 
$info= $_POST['info'];
$sessionID = $_POST['SessionID'];

require 'connection.php';

$sql = "INSERT INTO sprit (Zeit, Fahrer, Menge, Info, SessionID) VALUES ('$time', '$driver', '$menge','$info','$sessionID')";

$ergebnis = $con->query($sql)
or die($con->error);

echo "Tankvorgang erfolgreich eingegeben";

mysqli_close($con);

echo '<br><br>';

echo '<a href="../mitarbeiter.php">Zurueck zur Eingabe</a>';

?>
