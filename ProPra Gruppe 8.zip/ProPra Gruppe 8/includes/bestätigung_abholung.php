<?php
require 'connection.php'; 
if(isset($_POST['save_select'])){
$status = $_POST['status'];
$Reifensatz = $_POST['Reifensatz'];

$sql ="UPDATE  `reifen2` SET  `Status` = '$status' WHERE `Reifensatz` = '$Reifensatz'";

$ergebnis = $con->query($sql)
or die($con->error);

  header('location: ../mitarbeiter.php');


mysqli_close($con);
      }
  ?>