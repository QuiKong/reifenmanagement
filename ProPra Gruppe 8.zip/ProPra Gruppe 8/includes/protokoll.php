<?php 
session_start();
if(!isset($_SESSION["username"])){
    header("Location: login.html");
    exit;
}

?>
<h4 class="txt-title">Wetterwerte</h4> 

      <table class="table">

        <tr>

           <td>Tag</td>            
           <td>Uhrzeit</td>        
           <td>Luft</td>              
           <td>Strecke</td>           
           <td>Streckenverhältnisse</td>
      
        </tr>

        <?php
        
        
include 'connection.php';


$dat = $_SESSION['datum'];

$stmt2 = "SELECT * FROM wetter where `Datum` = '$dat' ";
$result2 = $con->query($stmt2);



if($result2->num_rows > 0){

  
  
  while( $row2 = $result2->fetch_assoc()){
    
?>
        <tr>

        

         <td id="Tag"><?php echo date("d.m.Y", strtotime($row2['Datum']));?></td>            
         <td id="Uhrzeit"><?php echo $row2['Zeit'];?></td>        
         <td id="Luft"><?php echo $row2['LuftTemp'];?>°C</td>              
         <td id="Strecke"><?php echo $row2['StreckenTemp'];?>°C</td>           
         <td id="Streckenverhältnisse"><?php echo $row2['Streckenverhaeltnisse'];?> </td>
     
       </tr>
          
          
       <?php
    
  }
}else {echo "Keine Wetterdaten zur gewählten Session verfügbar.";}
?> 
          </table>
        <br>


        <br>
         <!-- Tankhistorie anzeigen lassen -->          
<h4 class="txt-title"> Tankhistorie</h4>
    <table class="table">
        <tr>

            <td>Session</td>
            <td>Uhrzeit</td>
            <td>Fahrer</td>
            <td>Menge in Liter</td> 
            <td>Bemerkung</td> 
      </tr>



    

<?php 
include 'connection.php';

$sess = $_SESSION['sess'];

$sql = "SELECT session.Session, sprit.Zeit, sprit.Fahrer, sprit.Menge, sprit.Info FROM session, sprit where sprit.SessionID=session.SessionID AND sprit.SessionID = '$sess' ";
$result = $con->query($sql);


if ($result->num_rows > 0){
    
    while ($row = $result->fetch_assoc()){
    ?>    
        <tr>
            <td id="Session"><?php echo $row['Session'];?></td>
            <td id="Uhrzeit"><?php echo $row['Zeit'];?></td>
            <td id="Fahrer"><?php echo $row['Fahrer'];?></td>
            <td id="Menge"><?php echo $row['Menge'];?></td>
            <td id="Bemerkung"><?php echo $row['Info'];?></td>           
        </tr>
    <?php
    }
} else {echo "Keine Tankdaten zur gewählten Session verfügbar.";}
?> 
        
        
        </table>
                   