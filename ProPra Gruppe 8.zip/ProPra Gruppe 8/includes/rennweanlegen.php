<?php
/*
session_start();
if(!isset($_SESSION["username"])){
    header("Location: login.html");
    exit;
}
*/
?>

<?php


mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);




if(isset($_POST["WEanlegen"])){

   include "./connection.php";

        $von = $_POST["von_datum"];
        $bis = $_POST["bis_datum"];
        $strecke = $_POST["strecke"];
        $format = $_POST["format"];
        $kontingent = $_POST["gesamtkontingent"];
        $bemerkung = $_POST["bemerkung"];

        $von = stripslashes($von);
        $bis = stripslashes($bis);
        $strecke = stripslashes($strecke);
        $format = stripslashes($format);
        $kontingent = stripslashes($kontingent);
        $bemerkung = stripslashes($bemerkung);
        
        $von = mysqli_real_escape_string($con, $von);
        $bis = mysqli_real_escape_string($con, $bis);
        $strecke = mysqli_real_escape_string($con, $strecke);
        $format = mysqli_real_escape_string($con, $format);
        $kontingent = mysqli_real_escape_string($con, $kontingent);
        $bemerkung = mysqli_real_escape_string($con, $bemerkung); 

        $stmt = "INSERT INTO `rennwochenende` (`Von_Datum`, `Bis_Datum`, `Strecke`, `Format`, `Gesamtkontingent`, `Bemerkung`) VALUES ('$von', '$bis', '$strecke','$format','$kontingent', '$bemerkung')";
        if($con->query($stmt) == TRUE){
          
            echo "Rennwochenende erfolgreich erstellt"; 
            
             
             
              

           
        };
       



    mysqli_close($con);
  
}
echo '<br><br>' ;
echo '<a href="../manager.php">Zurueck zur Eingabe</a>';

?>