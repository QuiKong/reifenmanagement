<?php
require 'includes/connection.php';
$sql = "SELECT * FROM wetter ORDER BY Datum";
$result = $con->query($sql);
if ($result->num_rows > 0) {
  $arr = [];
  while ($row = $result->fetch_assoc()) {
    array_push($arr, [
      'Datum' => date("d.m.Y", strtotime($row['Datum'])),
      'Zeit' => $row['Zeit'],
      'LuftTemp' => $row['LuftTemp'],
      'StreckenTemp' => $row['StreckenTemp'],
      'Streckenverhaeltnisse' => $row['Streckenverhaeltnisse'],
    ]);
  }
  echo json_encode($arr);
}
