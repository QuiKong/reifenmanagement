let seconds = 5
let timerLoop = false

const timerLeft = document.getElementById("timer_left")
const cancelTimers = document.getElementById("cancelTimers")
const select_minuts = document.getElementById("select_minuts")
const select_hours = document.getElementById("select_hours")

if (seconds > 0) {
    startTimers(seconds)
}

// function when click btn start 
function startTimers(seconds) {
    if (timerLoop === false && seconds > 0) {
        timerLoop = setInterval(() => {
            timerLeft.innerHTML = convertTime(seconds)
            if (seconds > 0) {
                seconds--
            } else {
                clearInterval(timerLoop)
                timerLoop = false
                document.getElementById("audio").pause()
            }
            if (seconds === 7) {
                document.getElementById("audio").play()
            }
        }, 1000);
    }
}


// for convert number seconds to normal time for user
function convertTime(allSeconds) {
    let hor = Math.floor(allSeconds / 3600);
    let min = Math.floor((allSeconds - (hor * 3600)) / 60);
    let sec = allSeconds % 60;
    hor = (hor < 10) ? "0" + hor : hor;
    min = (min < 10) ? "0" + min : min;
    sec = (sec < 10) ? "0" + sec : sec;
    return `${hor}:${min}:${sec}`
}




// bottom timer


let formInsertTimer = document.getElementById("form_insert_weat")
let timerLoopDown = false
let ifTimerAlready = localStorage.getItem('secCurr')
let startTimerSeocnds = 1800  // change your time 

form_insert_weat.addEventListener('submit', async (e) => {
    e.preventDefault()
    document.getElementById("model3").classList.add('active')

    if (ifTimerAlready && ifTimerAlready > 0) {
        clearInterval(timerLoopDown)
        timerLoopDown = false
        localStorage.setItem('secCurr', 0)
        setAgainTimer(startTimerSeocnds)
    } else {
        setAgainTimer(startTimerSeocnds)
    }

    // send request to server
    let form = new FormData(document.getElementById('form_insert_weat'));
    fetch("includes/wetter_insert.php", {
        method: "POST",
        body: form
    }).then(() => {
        fetch("getConnection.php")
            .then(res => res.json())
            .then(data => {
                document.getElementById("table").innerHTML = ''
                document.getElementById("table").innerHTML = `
            <tr>
            <td>Datum</td>
            <td>Uhrzeit</td>
            <td>Lufttemperatur</td>
            <td>Streckentemperatur</td>
            <td>Streckenverhaeltnisse</td>
          </tr>
            `
                for (let i = 0; i < data.length; i++) {
                    document.getElementById("table").innerHTML += `
                <tr>
                <td id="Session">${data[i].Datum}</td>
                <td id="Uhrzeit">${data[i].Zeit}</td>
                <td id="Fahrer">${data[i].LuftTemp}</td>
                <td id="Menge">${data[i].StreckenTemp}</td>
                <td id="Bemerkung">${data[i].Streckenverhaeltnisse}</td>
              </tr>
              `
                }


            })
    })
})

function closePopsFinish() {
    document.getElementById("model3").classList.remove('active')
    document.getElementById("pop_finishTimers").classList.remove('active')
}

console.log(ifTimerAlready);
if (ifTimerAlready && ifTimerAlready > 0) {
    console.log(ifTimerAlready);
    setAgainTimer(ifTimerAlready)
    document.getElementById("model3").classList.add('active')
}

function setAgainTimer(secCurr) {
    timerLoopDown = setInterval(() => {
        convertTime(secCurr)
        document.getElementById("timer").innerHTML = convertTime(secCurr)
        if (secCurr > 0) {
            secCurr--
            localStorage.setItem('secCurr', secCurr)
        } else {
            clearInterval(timerLoopDown)
            timerLoopDown = false
            localStorage.setItem('secCurr', 0)
            document.getElementById("pop_finishTimers").classList.add('active')
        }
    }, 1000);

}


