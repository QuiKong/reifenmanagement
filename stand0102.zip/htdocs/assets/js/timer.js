let seconds = 0
let currentTime = ''
let timerLoop = false
let stateTimer = false


const timerLeft = document.getElementById("timer_left")
const bowl = document.getElementById("bowl")
const cancelTimers = document.getElementById("cancelTimers")
const select_minuts = document.getElementById("select_minuts")
const select_hours = document.getElementById("select_hours")
const audio = document.getElementById("audio")


// when click show pop timer
timerLeft.addEventListener('click', () => {

    if (stateTimer) {
        document.getElementById("active_timer_do").classList.add('active')

    } else {
        document.getElementById("bowl").classList.add('active')
        stateTimer = true
    }
})


// when click remove the pop timer
function removePOp() {
    document.getElementById("bowl").classList.remove('active')
}
function closePop() {
    document.getElementById("active_timer_do").classList.remove('active')
}

function pauseTimer() {

    if (timerLoop !== false) {
        clearInterval(timerLoop)
        timerLoop = false
        document.getElementById("btn_pause_timers").innerHTML = 'running'
    } else {
        interValTimer()
        document.getElementById("btn_pause_timers").innerHTML = 'pause'
    }
}

function cancelOrder() {

    document.getElementById("active_timer_do").classList.remove('active')
    seconds = 0
    clearInterval(timerLoop)
    timerLoop = false
        stateTimer = false
        currentTime = `00:00`
    timerLeft.innerHTML = currentTime
    // send cancel to server

}


function removePOpFinish() {
    document.getElementById("msg_finish_timer").classList.remove('active')
    document.getElementById("audio").pause()
}


// function when click btn start 
function startTimers() {

    if (seconds === 0) {
        let hours = document.getElementById("select_hours")
        let mins = document.getElementById("select_minuts")
        let timeHours = Number(hours.options[hours.selectedIndex].value)
        let timesMins = Number(mins.options[mins.selectedIndex].value)
        timeHours = timeHours > 0 ? timeHours * 60 * 60 : 0
        timesMins = timesMins > 0 ? timesMins * 60 : 0
        seconds = timeHours + timesMins
    }

    if (timerLoop === false && seconds > 0) {
        interValTimer()
    }

    document.getElementById("bowl").classList.remove('active')


}



function interValTimer() {
    timerLoop = setInterval(() => {
        convertTime(seconds)
        timerLeft.innerHTML = currentTime
        if (seconds > 0) {
            seconds--
        } else {
            document.getElementById("msg_finish_timer").classList.add('active')
            clearInterval(timerLoop)
            timerLoop = false
            document.getElementById("audio").pause()
        }
        if (seconds === 7) {
            document.getElementById("audio").play()
        }
    }, 1000);
}



// for convert number seconds to normal time for user
function convertTime(allSeconds) {
    let hor = Math.floor(allSeconds / 3600);
    let min = Math.floor((allSeconds - (hor * 3600)) / 60);
    let sec = allSeconds % 60;
    hor = (hor < 10) ? "0" + hor : hor;
    min = (min < 10) ? "0" + min : min;
    sec = (sec < 10) ? "0" + sec : sec;
    let id = document.getElementById("id_order").value
    currentTime = `${hor}:${min}:${sec} | ID order: ${id} `
}










