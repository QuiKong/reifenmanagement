<?php /*
include('./includes/auth_check.php');

if(isset($_SESSION['role']) && $_SESSION['role'] != 'Manager'){
  if($_SESSION['role'] == "Mitarbeiter"){
    header('location: mitarbeiter.php');
    exit;
  } else {
    header('location: ingenieur.php');
    exit;
  }
}

*/
?>


<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="assets/css/pages.css">
  <link rel="stylesheet" href="assets/css/timer.css">
  <script type="text/javascript" src="assets/js/script.js"></script>
</head>

<body>

  <div class="navbar">
    <div class="menu">
      <input type="hidden" data-time="300" class="time-set" />
      <a class="tablinks" id="timer_left" style="float: left;">00:00</a>
      <a class="end_time"></a>
      <a class="tablinks" onclick="opentab(event, 'Einstellung')">Einstellung </a>
      <a class="tablinks" onclick="window.location.href='./includes/abmelden.php';"> Logout</a>
    </div>
  </div>




  <div class="tab">
    <img src="./assets/images/lms_logo_retina.png" style="max-width:220; min-width:auto; padding-bottom: 5px;">
    <iframe style="max-width: 220px; border: none; max-height: 65px; min-width:auto; background-color: transparent;" src="https://www.wetter.de/widget/mini/u1j9qt/L2RldXRzY2hsYW5kL3dldHRlci1rb2Vsbi0xODIyMDY3OS5odG1s/">
    </iframe>
    <form action="./includes/sessionwahl.php" method="post">
      <table class="tablinks">
        <tr>
          <td>
            <?php
            include './includes/sessionwahl.php';
            echo $opt;
            ?>
          </td>
          <td><button name="Add" id="addRow" type="submit" class="btn-block"> Session Auswählen </td>

        </tr>

      </table>
      </form>
      <button class="tablinks active" onclick="opentab(event, 'Benachrichtigungen')" id="defaultOpen">Benachrichtigungen</button>
      <button class="tablinks" onclick="opentab(event, 'Reifensorganisation')">Reifensorganisation</button>
      <button class="tablinks" onclick="opentab(event, 'Rennwochenende')">Rennwochenende</button>
      <button class="tablinks" onclick="opentab(event, 'Statistik')">Statistik</button>
      <button class="tablinks" onclick="opentab(event, 'Protokoll')">Protokoll</button>

  </div>





  <!----------------- Benachrichtigungen-------------------------------->

  <div id="Benachrichtigungen" class="tabcontent" style="display: block;">





    <h4 class="txt-title">Offene Bestellungen</h4>


     

          

          <table class="table">
            <tbody>
               
                <?php 
                 require 'includes/connection.php';

                 $stmt2 = "SELECT DISTINCT * FROM reifen2 WHERE `status` = 1" ;
                 $result2 = $con->query($stmt2);
                 if($result2->num_rows > 0){
          
                  while( $row = $result2->fetch_assoc()){
                    ?>
                    <tr> 
                      
                          <td> 
                          <form action= "includes/bestellungNR.php" method="POST">
                            neuer Reifensatz wartet auf Bestellung
                            <input type="hidden" name="Reifensatz" value="<?php echo $row['Reifensatz'];?>">
                            <button class="btn-block2"  type="submit" name="save_select" href="./includes/bestellungNR.php"  >
                            
                            <?php echo $row['Reifensatz'];?> 
                            </button>
                            </form>
                        </td> 
                       
      
                <form action= "includes/bestätigung.php" method="POST">
            
                <td>
                  <select name="status" id="status">
                    <option type="int" value=2>Bestellen</option>
                    <option type="int" value=8>Ablehnen</option>
                  </select>
                  <input type="hidden" name="Reifensatz" value="<?php echo $row['Reifensatz'];?>">
                </td> 
                    <td> <button class="btn-block2" type="submit" name="save_select">Bestätigen </button></td>
               </form>

              </tr> 
              <?php
                          }
                  
                          } else {echo "keine ausstehenden Bestellungen";}
                        ?>
            </tbody>
          </table>
      
      <br>
      
      
        <h4 class="txt-title">Bestellte Reifensätze</h4>  
      <table class="table">
            <tbody>
               
                <?php 
                 require 'includes/connection.php';

                 $stmt2 = "SELECT DISTINCT * FROM reifen2 WHERE `status` = 2" ;
                 $result2 = $con->query($stmt2);
                 if($result2->num_rows > 0){
          
                  while( $row = $result2->fetch_assoc()){
                    ?>
                    <tr> 
                      
                          <td> 
                          <form action= "includes/bestellungNR.php" method="POST">
                            in Bearbeitung
                            <input type="hidden" name="Reifensatz" value="<?php echo $row['Reifensatz'];?>">
                            <button class="btn-block2"  type="submit" name="save_select" href="./includes/bestellungNR.php"  >
                            
                            <?php echo $row['Reifensatz'];?> 
                            </button>
                            </form>
                        </td> 

              </tr> 
              <?php
                          }
                          } else {echo "keine bestellten Reifensätze";}
                 
                        ?>
            </tbody>
          </table>
      <br>
      
      <h4 class="txt-title">zu beschriftende Reifensätze</h4>  
      <table class="table">
            <tbody>
               
                <?php 
                 require 'includes/connection.php';

                 $stmt2 = "SELECT DISTINCT * FROM reifen2 WHERE `status` = 3" ;
                 $result2 = $con->query($stmt2);
                 if($result2->num_rows > 0){
          
                  while( $row = $result2->fetch_assoc()){
                    ?>
                    <tr> 
                      
                          <td> 
                          <form action= "includes/bestellungNR_MA.php" method="POST">
                            Reifensatz
                            <input type="hidden" name="Reifensatz" value="<?php echo $row['Reifensatz'];?>">
                            <button class="btn-block2"  type="submit" name="save_select" href="./includes/bestellungNR.php"  >
                            
                            <?php echo $row['Reifensatz'];?> 
                            </button>
                            </form>
                        </td> 
                        <form action= "includes/beschriftung.php" method="POST">
            
                <td>
                    <input  name="status" id="status" value=4>
                  <input type="hidden" name="Reifensatz" value="<?php echo $row['Reifensatz'];?>">
                </td> 
                    <td> <button class="btn-block2" type="submit" name="save_select">Reifensatz beschriftet </button></td>
               </form>

              </tr> 
              <?php
                          }
                          } else {echo "keine unbeschrifteten Reifensätze";}
                 
                        ?>
            </tbody>
          </table>

<br>

  </div>




  <!--------------------------------Reifensorganisation-------------------------------->
  <div id="Reifensorganisation" class="tabcontent" style="display: none;">
    <div w3-include-html="includes/reifenorg.php">
    </div>


  </div>
  <!--------------------------------Statistik-------------------------------->
  <div id="Statistik" class="tabcontent" style="display: none;">
    <div style="width:100%; min-width:700px; height:auto; float:left">
      <title>LuftTemp & StreckenTemp</title> <?php include('includes/statistik.php'); ?>
    </div>

  </div>
  <!--------------------------------Diagramm-------------------------------->

  <div id="Diagramm" class="tabcontent" style="display: none;">

    <div style="width:100%; min-width:700px; height:auto; float:left">
      <title>Kontingenten der Reifensätze</title> <?php include('includes/chart.php'); ?>
    </div>

  </div>
  <!--------------------------------Protokoll -------------------------------->

  <div id="Protokoll" class="tabcontent" style="display: none;">
    <div w3-include-html="includes/protokoll.php"></div>

  </div>

  <!--------------------------------Einstellung -------------------------------->

  <div id="Einstellung" class="tabcontent" style="display: none;">
    <p>Ändern Sie ihr Passwort für Sicherheit!</p>
    <br>
    <div class="body">
      <p><label for="pass1">Passwort :</label>
        <input type="text" id="pass1" name="pass1" minlength="8" required>
      </p>

      <p><label for="pass2">Wiederholen:</label>
        <input type="text" id="pass2" name="pass2">
      </p>

    </div>

    <input type="submit" value="Sign in">
  </div>

  <!--------------------------------Bestellung-NR-------------------------------->

  <div id="Bestellung-NR" class="tabcontent" style="display: none;">
    <div w3-include-html="includes/bestellungNR.php"></div>
  </div>






  <!--------------------------------Offene Bestellungen-------------------------------->

  <div id="Offene Bestellung" class="tabcontent" style="display: none;">
    <div style="padding: 20px;">
      <h4 class="txt-title">Offene Bestellungen</h4>
      <table class="table">
        <tr>
          <td>Bestell-Nr.</td>
          <td>Reifensatz-ID</td>
          <td>Datum</td>
          <td>Uhrzeit</td>
        </tr>
        <?php
        require 'includes/connection.php';


        $sql = "SELECT * FROM bestellung WHERE Status=1";
        $result = $con->query($sql);


        if ($result->num_rows > 0) {

          while ($row = $result->fetch_assoc()) {
        ?>
            <tr>
              <td id="Bestell-Nr."><?php echo $row['BestellNr']; ?></td>
              <td id="Reifensatz-ID"><?php echo $row['Reifensatz']; ?></td>
              <td id="Datum"><?php echo date("d.m.Y", strtotime($row['Datum'])); ?></td>
              <td id="Uhrzeit"><?php echo $row['Zeit']; ?></td>
            </tr>
        <?php
          }
        }
        ?>

      </table>

    </div>
  </div>




  <!----------------- Rennwochenende -------------------------------->

  <div id="Rennwochenende" class="tabcontent" style="display: none;">
    <div w3-include-html="includes/rennWE.php"></div>
  </div>

  <script>
    includeHTML();
  </script>
  <script type="text/javascript" src="assets/js/timer.js"></script>



  <!-- start timer -->
  <div class="msg_finish_timer" id="msg_finish_timer">
    <span>Die Reifen sind Abholbereit!</span>
    <button onclick='removePOpFinish()' id='cancelTimers' class='cancel'>Ok</button>
  </div>

  <div class="audioNotif">
    <audio id='audio' controls src="assets/mixkit-warning-alarm-buzzer-991.wav"></audio>
  </div>


  <div id="bowl" class='bowl'>
    <div class="timer_option">
      <div class="bowl_select">
        <select name="" id="select_hours" class="select_hours">
          <option value="0">00</option>
          <option value="1">01</option>
          <option value="2">02</option>
          <option value="3">03</option>
          <option value="4">04</option>
          <option value="5">05</option>
          <option value="6">06</option>
          <option value="7">07</option>
          <option value="8">08</option>
          <option value="9">09</option>
          <option value="10">10</option>
        </select>
        <span>H</span>
      </div>
      <div class="bowl_select">
        <select name="" id="select_minuts" class="select_minuts">
          <option value="1">00</option>
          <option value="1">01</option>
          <option value="2">02</option>
          <option value="3">03</option>
          <option value="4">04</option>
          <option value="5">05</option>
          <option value="6">06</option>
          <option value="7">07</option>
          <option value="8">08</option>
          <option value="9">09</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>
          <option value="13">13</option>
          <option value="14">14</option>
          <option value="15">15</option>
          <option value="16">16</option>
          <option value="17">17</option>
          <option value="18">18</option>
          <option value="19">19</option>
          <option value="20">20</option>
          <option value="21">21</option>
          <option value="22">22</option>
          <option value="23">23</option>
          <option value="24">24</option>
          <option value="25">25</option>
          <option value="26">26</option>
          <option value="27">27</option>
          <option value="28">28</option>
          <option value="29">29</option>
          <option value="30">30</option>
          <option value="31">31</option>
          <option value="32">32</option>
          <option value="33">33</option>
          <option value="34">34</option>
          <option value="35">35</option>
          <option value="36">36</option>
          <option value="37">37</option>
          <option value="38">38</option>
          <option value="39">39</option>
          <option value="40">40</option>
          <option value="41">41</option>
          <option value="42">42</option>
          <option value="43">43</option>
          <option value="44">44</option>
          <option value="45">45</option>
          <option value="46">46</option>
          <option value="47">47</option>
          <option value="48">48</option>
          <option value="49">49</option>
          <option value="50">50</option>
          <option value="51">51</option>
          <option value="52">52</option>
          <option value="53">53</option>
          <option value="54">54</option>
          <option value="55">55</option>
          <option value="56">56</option>
          <option value="57">57</option>
          <option value="58">58</option>
          <option value="59">59</option>
          <option value="60">60</option>
        </select>
        <span>M</span>
      </div>

    </div>

    <div class="serail_order">
      <input type="number" id='id_order' placeholder='BestellungNr'>
    </div>

    <div class="btns">
      <button onclick='startTimers()'>start</button>
      <button onclick='removePOp()' id='cancelTimers' class='cancel'>cancel</button>
    </div>
  </div>



  <div class="active_timer_do" id='active_timer_do'>
    <div class="btns_pop2 btns">
      <button onclick='pauseTimer()' id='btn_pause_timers'>pause</button>
      <button onclick='cancelOrder()' id='cancelTimerBtn' class='cancel'>cancel</button>
    </div>
    <button onclick='closePop()' id='closePpobtn' class='closeBtn'>close</button>
  </div>


</body>

</html>