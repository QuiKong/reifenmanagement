<?php

$Reifenplatz = $_POST['Reifenplatz'];
$Reifenart = $_POST['Reifenart'];
$Mischung= $_POST['Mischung'];
$Bezeichnung = $_POST['Bezeichnung'];
$Bearbeitungsvarianten = $_POST['Bearbeitungsvarianten'];
$Kontingent= $_POST['Kontingent'];






require 'connection.php'; //Referenz auf die Connection damit die Datenbankverbindung aufgebaut wird.


//Erstellen des SQL Ausdruck. Dieser wird in $SQL gespeichert.

$sql ="INSERT INTO `neu_bestellung` (`neu_bestellung_id`, `Reifenplatz`, `Reifenart`, `Mischung`, `Bezeichnung`, `Bearbeitungsvarianten`, `Kontingent`, `status`)
 VALUES (NULL,'$Reifenplatz', '$Reifenart', '$Mischung', '$Bezeichnung','$Bearbeitungsvarianten', '$Kontingent', 1 )";



//Ausführen des SQL-Befehls. Bei Erfolg kommt die untenstehende Meldung. Ansonsten eine Fehlermeldung.
$ergebnis = $con->query($sql)
or die($con->error);

    header('location: thank_page.php');

//Die Datenbankverbindung wird wieder getrennt.

mysqli_close($con);


?>
