

<h4 class="txt-title">Reifenübersicht</h4>     
      <form  action="./includes/reifenorg.php" method="post">
            <table class="table">
            <tr>
              <th>Reifensatz</th>  
              <th>Status</th>
            </tr>

          
   
            <tr>    
              
              <td><input name="reifensatz" id="Reifensatz" type="text" value="" class="adding"></td>
              
              <td><select id="Status" name="status">
                <option value="bestellt">bestellt</option>
                <option value="abgeholt">abgeholt</option>
                <option value="beschriftet">beschriftet</option>
                <option value="heizen">heizen</option>
                <option value="Einsatz">Einsatz</option>
                <option value="gebraucht">gebraucht</option>
             </select> </td>
            </tr>
         
             
             
          </table>
        </form>
 

         




