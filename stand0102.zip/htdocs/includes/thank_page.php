










<!DOCTYPE html>
<html lang="de-DE">
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../assets/css/pages.css">
    <link rel="stylesheet" href="../assets/css/thank_page.css">
    <link rel="stylesheet" href="../assets/css/timer.css">
    <script type="text/javascript" src="../assets/js/script.js"></script>
    </head>

    <body>
        <div class="navbar">

            <div class="menu">
            <input type="hidden" data-time="300" class="time-set" />
            <a class="tablinks" id="timer_left"  style="float: left;">00:00</a>
            <a class="end_time"></a>
            <a class="tablinks" onclick="opentab(event, 'Einstellung')">Einstellung </a>
            <a class="tablinks" onclick="window.location.href='abmelden.php';"> Logout</a>
            </div>
        </div>
        <section class="login-main-wrapper">
          <div class="main-container">
              <div class="login-process">
                  <div class="login-main-container">
                      <div class="thankyou-wrapper">
                          <h1><img src="http://montco.happeningmag.com/wp-content/uploads/2014/11/thankyou.png" alt="thanks" /></h1>
                            <a href="../ingenieur.php">Zurück zur Seite</a>
                            <div class="clr"></div>
                        </div>
                        <div class="clr"></div>
                    </div>
                </div>
                <div class="clr"></div>
            </div>
       </section>
    </body>
</html>
