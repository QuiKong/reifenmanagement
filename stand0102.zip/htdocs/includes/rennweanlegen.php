<?php

$Von_Datum = $_POST['Von_Datum'];
$Bis_Datum = $_POST['Bis_Datum'];
$Strecke= $_POST['Strecke'];
$Format = $_POST['Format'];
$Gesamtkontingent= $_POST['Gesamtkontingent'];
$Bemerkung = $_POST['Bemerkung'];


require 'connection.php'; //Referenz auf die Connection damit die Datenbankverbindung aufgebaut wird.


//Erstellen des SQL Ausdruck. Dieser wird in $SQL gespeichert.

$sql ="INSERT INTO `rennwochenende` (`Von_Datum`,`Bis_Datum`,`Strecke`,`Format`,`Gesamtkontingent`,`Bemerkung`)
 VALUES ('$von', '$bis', '$strecke', '$rennformat','$Kontingent', '$bemerkung')";



//Ausführen des SQL-Befehls. Bei Erfolg kommt die untenstehende Meldung. Ansonsten eine Fehlermeldung.
$ergebnis = $con->query($sql)
or die($con->error);

    header('location: ../manager.php');

//Die Datenbankverbindung wird wieder getrennt.

mysqli_close($con);


?>
<?php
