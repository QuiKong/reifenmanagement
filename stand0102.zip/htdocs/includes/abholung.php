<?php

require 'connection.php'; 

if(isset($_POST['set_timer'])){
$BesttelungsNR = $_POST['BesttelungsNR'];
$Abholungszeit= $_POST['Abholungszeit'];


$sql ="INSERT INTO `abholung` (`id`,`BesttelungsNR`,`Abholungszeit`)
 VALUES (NULL,'$BesttelungsNR', '$Abholungszeit')";
}
if(isset($_POST['reset_timer'])){
    $BesttelungsNR = $_POST['BesttelungsNR'];
    $Abholungszeit= $_POST['Abholungszeit'];
    
    $var_time = "SELECT Abholungszeit FROM abholung ORDER BY Abholungszeit DESC LIMIT 1"; 

    $sql ="UPDATE `abholung` SET  `Abholungszeit` = '$Abholungszeit' WHERE `BesttelungsNR` = $BesttelungsNR";
    
    }

$ergebnis = $con->query($sql)
or die($con->error);
    header('location: ../manager.php');
mysqli_close($con);

?>