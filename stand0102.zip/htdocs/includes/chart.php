<?php include('connection.php');?>

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
   
    <div id="piechart"></div>
   
   <script type="text/javascript">
      
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Reifensatz', 'Reifenart'],
         <?php
         $sql = "SELECT * FROM reifen";
         $fire = mysqli_query($con,$sql);
          while ($result = mysqli_fetch_assoc($fire)) {
            echo"['".$result['Reifensatz']."',".$result['Reifenart']."],";
          }

         ?>
        ]);

        var options = {
          title: 'Kontenginten der Reifensätze '
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
  
  
 
