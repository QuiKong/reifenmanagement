<?php include('connection.php');?>

      
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
       
   
        <div id="my-chart" ></div>
        <script type="text/javascript">
            google.charts.load('current', {'packages': ['corechart'] });
            google.charts.setOnLoadCallback(drawRegionsMap);

            function drawRegionsMap() {
                var data = google.visualization.arrayToDataTable([
                    ['Zeit', 'Luft', 'Strecke'],
                     <?php
                     $chartQuery = "SELECT * FROM wetter";
                     $chartQueryRecords = mysqli_query($con, $chartQuery);
                        while($row = mysqli_fetch_assoc($chartQueryRecords)){
                            echo "['".$row['Zeit']."',".$row['LuftTemp'].",".$row['StreckenTemp']."],";
                        }
                     ?>
                ]);

                var options = {
                    title: 'LuftTemp & StreckenTemp'
                };

                var chart = new google.visualization.LineChart(document.getElementById('my-chart'));
                chart.draw(data, options);
            }
        </script>
    