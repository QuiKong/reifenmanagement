<form  action="sessionwahl.php" method="post">
            <table class="table">
            <tr>  
              <?php 
              include 'sessionwahl.php';
              echo $opt;
              ?>
            </tr>

            <tr> 
              <td></td> 
              <td><button name="Add" id="addRow" type="submit" >Show</td>
            </tr>
         
          </table>
       </form>