-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 03. Feb 2022 um 15:03
-- Server-Version: 10.4.22-MariaDB
-- PHP-Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `management`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `abholung`
--

CREATE TABLE `abholung` (
  `id` int(11) NOT NULL,
  `BesttelungsNR` int(11) NOT NULL,
  `Abholungszeit` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `abholung`
--

INSERT INTO `abholung` (`id`, `BesttelungsNR`, `Abholungszeit`) VALUES
(1, 0, '00:00:00'),
(2, 0, '00:00:00'),
(3, 0, '00:00:00'),
(4, 0, '00:00:00'),
(5, 0, '00:00:00'),
(6, 0, '00:00:00');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `bestellung`
--

CREATE TABLE `bestellung` (
  `BestellNr` int(11) NOT NULL,
  `Reifensatz` int(11) NOT NULL,
  `Datum` date NOT NULL,
  `Zeit` time NOT NULL,
  `Status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `neu_bestellung`
--

CREATE TABLE `neu_bestellung` (
  `neu_bestellung_id` int(11) NOT NULL,
  `Reifenplatz` varchar(255) NOT NULL,
  `Reifenart` varchar(255) NOT NULL,
  `Mischung` varchar(255) NOT NULL,
  `Bezeichnung` varchar(255) NOT NULL,
  `Bearbeitungsvarianten` varchar(255) NOT NULL,
  `Kontingent` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `neu_bestellung`
--

INSERT INTO `neu_bestellung` (`neu_bestellung_id`, `Reifenplatz`, `Reifenart`, `Mischung`, `Bezeichnung`, `Bearbeitungsvarianten`, `Kontingent`, `status`) VALUES
(19, 'Vorne_Links', 'Slicks', 'Slicks_1', '1xx', 'Extra_grooved', 2, 1),
(21, 'Vorne_Rechts', 'Rain', 'Intermediate(H+/E+)', '5xx', 'Siped', 8, 1),
(24, 'Vorne_Rechts', 'Slicks', 'Slicks_1', '5xx', 'Extra_grooved_siped', 0, 1),
(25, 'Vorne_Links', 'Slicks', 'Cold(H/E)', '3xx', 'text', 0, 1),
(26, '', '', '', '', '', 0, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `reifen`
--

CREATE TABLE `reifen` (
  `ReifenID` int(11) NOT NULL,
  `Reifensatz` int(11) NOT NULL,
  `Reifenart` text DEFAULT NULL,
  `Datum` date DEFAULT NULL,
  `Zeit` time DEFAULT NULL,
  `Spezifikation` text DEFAULT NULL,
  `Session` text DEFAULT NULL,
  `Kaltdruck_vl` float DEFAULT NULL,
  `Kaltdruck_hl` float DEFAULT NULL,
  `Kaltdruck_vr` float DEFAULT NULL,
  `Kaltdruck_hr` float DEFAULT NULL,
  `TempAbholung` int(11) DEFAULT NULL,
  `Zieldruck_vl` float DEFAULT NULL,
  `Zieldruck_hl` float DEFAULT NULL,
  `Zieldruck_vr` float DEFAULT NULL,
  `Zieldruck_hr` float DEFAULT NULL,
  `Zieltemp` int(11) DEFAULT NULL,
  `Start` time DEFAULT NULL,
  `Dauer` int(11) DEFAULT NULL,
  `Fertig` time DEFAULT NULL,
  `bleed_vl` float DEFAULT NULL,
  `bleed_hl` float DEFAULT NULL,
  `bleed_vr` float DEFAULT NULL,
  `bleed_hr` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `reifen`
--

INSERT INTO `reifen` (`ReifenID`, `Reifensatz`, `Reifenart`, `Datum`, `Zeit`, `Spezifikation`, `Session`, `Kaltdruck_vl`, `Kaltdruck_hl`, `Kaltdruck_vr`, `Kaltdruck_hr`, `TempAbholung`, `Zieldruck_vl`, `Zieldruck_hl`, `Zieldruck_vr`, `Zieldruck_hr`, `Zieltemp`, `Start`, `Dauer`, `Fertig`, `bleed_vl`, `bleed_hl`, `bleed_vr`, `bleed_hr`) VALUES
(22, 0, 'Cold', '2021-12-09', '18:09:00', 'keine', 'TopQ', 1.3, 1.2, 1.1, 0.9, 20, 0, 1.75, 1.8, 1.7, 90, '18:10:00', 50, '19:00:00', NULL, NULL, NULL, NULL),
(23, 0, 'Cold', '2021-12-09', '18:09:00', 'keine', 'TopQ', 1.3, 1.2, 1.1, 0.9, 20, 1.7, 1.75, 1.8, 1.7, 90, '18:10:00', 50, '19:00:00', NULL, NULL, NULL, NULL),
(25, 0, 'Cold', '2012-12-09', '18:30:00', 'G/W', 'Q1', 1.2, 1.4, 1.2, 1.2, 20, 1.9, 1.9, 1.8, 1.95, 90, '18:31:00', 60, '19:31:00', -0.2, -0.1, 0, -0.2),
(26, 0, 'Cold', '2021-12-09', '21:49:00', 'G/D', 'Q1', 1.2, 1.2, 1.2, 1.2, 20, 1.9, 1.9, 1.9, 1.9, 90, '21:50:00', 10, '22:00:00', -0.2, -0.1, -0.1, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `reifen2`
--

CREATE TABLE `reifen2` (
  `ID` int(11) NOT NULL,
  `Position` text NOT NULL,
  `Art` text NOT NULL,
  `Mischung` text NOT NULL,
  `Spezifikation` text NOT NULL,
  `Zieldruck` float NOT NULL,
  `Reifensatz` int(11) NOT NULL,
  `Status` int(11) NOT NULL,
  `Bestellzeitpunkt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `reifen2`
--

INSERT INTO `reifen2` (`ID`, `Position`, `Art`, `Mischung`, `Spezifikation`, `Zieldruck`, `Reifensatz`, `Status`, `Bestellzeitpunkt`) VALUES
(82, 'Vorne_Links', 'Slicks', '', 'Keine', 0, 123, 6, '2022-02-03 11:28:50'),
(83, 'Vorne_Rechts', 'Slicks', '', 'Keine', 0, 123, 6, '2022-02-03 11:28:50'),
(84, 'Hinten_Links', 'Slicks', '', 'Keine', 0, 123, 6, '2022-02-03 11:28:50'),
(85, 'Hinten_Rechts', 'Slicks', '', 'Keine', 0, 123, 6, '2022-02-03 11:28:50'),
(86, 'Vorne_Links', 'Slicks', '', 'Extra_grooved', 1.5, 456, 10, '2022-02-03 11:14:41'),
(87, 'Vorne_Rechts', 'Slicks', '', 'Siped', 1.4, 456, 10, '2022-02-03 11:14:41'),
(88, 'Hinten_Links', 'Slicks', '', 'Extra_grooved', 1.6, 456, 10, '2022-02-03 11:14:41'),
(89, 'Hinten_Rechts', 'Slicks', '', 'Siped', 1.7, 456, 10, '2022-02-03 11:14:41');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `reifensatz`
--

CREATE TABLE `reifensatz` (
  `Reifensatz` int(11) NOT NULL,
  `Bestell-Nr` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `reifensatz`
--

INSERT INTO `reifensatz` (`Reifensatz`, `Bestell-Nr`) VALUES
(1, 0),
(101, 0),
(102, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `rennwochenende`
--

CREATE TABLE `rennwochenende` (
  `WeID` int(11) NOT NULL,
  `Von_Datum` date NOT NULL,
  `Bis_Datum` date NOT NULL,
  `Strecke` text NOT NULL,
  `Format` text NOT NULL,
  `Gesamtkontingent` int(11) NOT NULL,
  `Bemerkung` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `rennwochenende`
--

INSERT INTO `rennwochenende` (`WeID`, `Von_Datum`, `Bis_Datum`, `Strecke`, `Format`, `Gesamtkontingent`, `Bemerkung`) VALUES
(1, '2022-01-06', '2022-01-09', 'Belgien-Spa', 'VLN', 30, 'Starker Regen vorhergesagt'),
(5, '2022-02-03', '2022-02-06', 'Silverstone', 'VLN', 48, ''),
(7, '2022-02-03', '2022-02-03', 'Spa', 'VLN', 122, '');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `session`
--

CREATE TABLE `session` (
  `SessionID` int(11) NOT NULL,
  `Session` text NOT NULL,
  `Datum` date NOT NULL,
  `Beginn` time NOT NULL,
  `Ende` time NOT NULL,
  `WeID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `session`
--

INSERT INTO `session` (`SessionID`, `Session`, `Datum`, `Beginn`, `Ende`, `WeID`) VALUES
(1, 'FP1', '2022-01-06', '18:00:00', '19:00:00', 1),
(2, 'FP2', '2022-01-07', '11:00:00', '12:00:00', 1),
(3, 'Q1', '2022-01-07', '12:30:00', '13:00:00', 1),
(4, 'Race', '2022-02-04', '12:14:00', '12:45:00', 5),
(5, '3', '2022-02-03', '13:32:00', '13:32:00', 7);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `sprit`
--

CREATE TABLE `sprit` (
  `VorgangsID` int(11) NOT NULL,
  `Session` text DEFAULT NULL,
  `Zeit` time DEFAULT NULL,
  `Fahrer` text DEFAULT NULL,
  `Menge` int(11) DEFAULT NULL,
  `Info` text DEFAULT NULL,
  `SessionID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `sprit`
--

INSERT INTO `sprit` (`VorgangsID`, `Session`, `Zeit`, `Fahrer`, `Menge`, `Info`, `SessionID`) VALUES
(1, 'Race', '12:24:00', 'RAS', 21, 'keine Probleme', 1),
(2, 'Q2', '15:56:00', 'KVL', 1, 'Hotlap', 1),
(3, 'Q2', '15:58:00', 'MIE', 2, 'Charge Lap', 1),
(4, 'Q3', '18:33:00', 'KVL', 22, 'Hot Lap', 1),
(5, 'WUP', '12:14:00', 'RAS', 23, '', 1),
(6, 'WUP', '12:14:00', 'RAS', 23, '', 1),
(8, NULL, '13:54:00', 'RAS', 23, '', 2),
(9, NULL, '14:45:00', 'MIE', 342, 'jo', 3);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `status`
--

CREATE TABLE `status` (
  `StatusID` int(11) NOT NULL,
  `Status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `status`
--

INSERT INTO `status` (`StatusID`, `Status`) VALUES
(1, 'offen'),
(2, 'bestellt'),
(3, 'abgeholt'),
(4, 'beschriftet'),
(5, 'heizen'),
(6, 'Einsatz'),
(7, 'gebraucht'),
(8, 'nicht_genehmigt'),
(9, 'genehmigt'),
(10, 'auf Lager');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `Name` text DEFAULT NULL,
  `Passwort` text DEFAULT NULL,
  `Rolle` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `users`
--

INSERT INTO `users` (`ID`, `Name`, `Passwort`, `Rolle`) VALUES
(1, 'User1', '$2a$12$CAYxf88ofhbtDtodwj/8/eYx82X72oDvyReyTvOp2Opl9kLY8eK9K\r\n', 'Manager'),
(2, 'User2', '$2a$12$XA8hgeovGtxbPqOPhPl8au92fLG8P9WZ4..dpwq9at1KpINZcCpVy\r\n', 'Mitarbeiter'),
(3, 'User3', '$2a$12$eOTmWrLCt.gylR2YKbLxRek3.w5mkU9VmO94mIq8JOjnmBc.EP0HG', 'Ingenieur');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `wetter`
--

CREATE TABLE `wetter` (
  `MessID` int(11) NOT NULL,
  `Datum` date DEFAULT NULL,
  `Zeit` time DEFAULT NULL,
  `LuftTemp` int(11) DEFAULT NULL,
  `StreckenTemp` int(11) DEFAULT NULL,
  `Streckenverhaeltnisse` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `wetter`
--

INSERT INTO `wetter` (`MessID`, `Datum`, `Zeit`, `LuftTemp`, `StreckenTemp`, `Streckenverhaeltnisse`) VALUES
(4, '2022-01-05', '13:00:00', 4, 15, 'regen'),
(6, '2022-01-31', '14:39:00', 7, 24, ''),
(7, '2022-01-31', '15:45:00', 12, 34, 'schnee'),
(8, '2022-02-01', '16:46:00', 2, 43, 'gut'),
(9, '2022-02-01', '17:48:00', 4, 32, 'nass'),
(11, '2022-02-01', '19:16:00', 2, 12, ''),
(12, '2022-02-02', '12:48:00', 4, 21, 'i.O'),
(13, '2022-02-03', '15:05:00', 12, 24, 'gut'),
(14, '2022-02-02', '14:14:00', 3, 21, 'gut'),
(15, '2022-02-02', '15:49:00', 1, 12, ''),
(16, '2022-02-03', '14:22:00', 12, 24, '');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `abholung`
--
ALTER TABLE `abholung`
  ADD KEY `id` (`id`);

--
-- Indizes für die Tabelle `bestellung`
--
ALTER TABLE `bestellung`
  ADD PRIMARY KEY (`BestellNr`),
  ADD KEY `Reifensatz` (`Reifensatz`),
  ADD KEY `Status` (`Status`) USING BTREE;

--
-- Indizes für die Tabelle `neu_bestellung`
--
ALTER TABLE `neu_bestellung`
  ADD PRIMARY KEY (`neu_bestellung_id`),
  ADD KEY `Status` (`status`);

--
-- Indizes für die Tabelle `reifen`
--
ALTER TABLE `reifen`
  ADD PRIMARY KEY (`ReifenID`);

--
-- Indizes für die Tabelle `reifen2`
--
ALTER TABLE `reifen2`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Reifensatz` (`Reifensatz`),
  ADD KEY `Status` (`Status`);

--
-- Indizes für die Tabelle `reifensatz`
--
ALTER TABLE `reifensatz`
  ADD PRIMARY KEY (`Reifensatz`),
  ADD KEY `Bestell-Nr` (`Bestell-Nr`);

--
-- Indizes für die Tabelle `rennwochenende`
--
ALTER TABLE `rennwochenende`
  ADD PRIMARY KEY (`WeID`);

--
-- Indizes für die Tabelle `session`
--
ALTER TABLE `session`
  ADD PRIMARY KEY (`SessionID`),
  ADD KEY `WeID` (`WeID`);

--
-- Indizes für die Tabelle `sprit`
--
ALTER TABLE `sprit`
  ADD PRIMARY KEY (`VorgangsID`),
  ADD KEY `SessionID` (`SessionID`);

--
-- Indizes für die Tabelle `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`StatusID`);

--
-- Indizes für die Tabelle `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- Indizes für die Tabelle `wetter`
--
ALTER TABLE `wetter`
  ADD PRIMARY KEY (`MessID`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `abholung`
--
ALTER TABLE `abholung`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT für Tabelle `bestellung`
--
ALTER TABLE `bestellung`
  MODIFY `BestellNr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT für Tabelle `neu_bestellung`
--
ALTER TABLE `neu_bestellung`
  MODIFY `neu_bestellung_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT für Tabelle `reifen`
--
ALTER TABLE `reifen`
  MODIFY `ReifenID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT für Tabelle `reifen2`
--
ALTER TABLE `reifen2`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT für Tabelle `reifensatz`
--
ALTER TABLE `reifensatz`
  MODIFY `Reifensatz` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT für Tabelle `rennwochenende`
--
ALTER TABLE `rennwochenende`
  MODIFY `WeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT für Tabelle `session`
--
ALTER TABLE `session`
  MODIFY `SessionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT für Tabelle `sprit`
--
ALTER TABLE `sprit`
  MODIFY `VorgangsID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT für Tabelle `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `wetter`
--
ALTER TABLE `wetter`
  MODIFY `MessID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `bestellung`
--
ALTER TABLE `bestellung`
  ADD CONSTRAINT `bestellung_ibfk_3` FOREIGN KEY (`Status`) REFERENCES `status` (`StatusID`);

--
-- Constraints der Tabelle `neu_bestellung`
--
ALTER TABLE `neu_bestellung`
  ADD CONSTRAINT `neu_bestellung_ibfk_1` FOREIGN KEY (`status`) REFERENCES `status` (`StatusID`);

--
-- Constraints der Tabelle `session`
--
ALTER TABLE `session`
  ADD CONSTRAINT `session_ibfk_1` FOREIGN KEY (`WeID`) REFERENCES `rennwochenende` (`WeID`);

--
-- Constraints der Tabelle `sprit`
--
ALTER TABLE `sprit`
  ADD CONSTRAINT `sprit_ibfk_1` FOREIGN KEY (`SessionID`) REFERENCES `session` (`SessionID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
