
<h4 class="txt-title">Reifenübersicht</h4>     
    
            <table class="table">
                
            <tr>
                <th>Reifensatz</th>  
                <th>Aktueller Status</th>
                <th>Status anpassen</th>
                <th></th>
            </tr>
<tbody>
          <?php 
                require 'connection.php';
                $sql ="SELECT DISTINCT reifen2.Reifensatz, status.Status FROM reifen2, status WHERE reifen2.status=status.StatusID" ;
                $result = $con->query($sql);
                if ($result->num_rows > 0){
                    while ($row = $result -> fetch_assoc()){
                    ?>
                <tr> 
                      
                          <td> 
                          <form action= "includes/bestellungNR.php" method="POST">
                            Reifensatz 
                            <input type="hidden" name="Reifensatz" value="<?php echo $row['Reifensatz'];?>"> 
                            <button class="btn-block2"  type="submit" name="save_select" href="./includes/bestellungNR.php"  >
                            
                            <?php echo $row['Reifensatz'];?> 
                            </button> anzeigen
                            
                    
                            </form>
                        </td> 
                    <td id="aktueller_Status"> <?php echo $row['Status'];?>
                    </td>
                    
                    <form action="status_anpassen.php" method="POST">
            
                <td>
                  <select name="status" id="status">
                    <option type="int" value=2>Neu bestellen</option>
                    <option type="int" value=3>Abgeholt</option>
                    <option type="int" value=4>Beschriftet</option>
                    <option type="int" value=5>heizen</option>
                    <option type="int" value=6>Einsatz</option>
                    <option type="int" value=8>Ablehnen</option>
                    <option type="int" value=10>Lager</option>
                  </select>
                  <input type="hidden" name="Reifensatz" value="<?php echo $row['Reifensatz'];?>">
                </td> 
                    <td> <button class="btn-block2" type="submit" name="save_select">Bestätigen </button></td>
              
               </form>
                </tr>
                 <?php       
                    }
                    
                    
                }
           
                ?>
                    </tbody>
        </table>
        
 

         




