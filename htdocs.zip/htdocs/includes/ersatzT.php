<h4 class="txt-title">Bestellungen Bearbeiten</h4>  

      
<form action= "includes/abholung.php" method="POST">
  <table class="table">
    <thead>
      <tr>
      <td>
        <label for="BesttelungsNR">BesttelungsNR</label>
      </td>
     
      <td>
        <label for="Abholungszeit">Abholungszeit</label>
      </td>
      <td></td>
      </tr>
    </thead>
    <tbody>
    <tr>
      <td>
        <input type="nummber" id="BesttelungsNR">
      </td>
    
      <td>
        <input  type="time"  id="Abholungszeit">
      </td>
      <td> <button type="submit" name="set_timer"> Absenden <button> </td>

      </tr>
    </tbody>
  </table>


</form>


<h4 class="txt-title"> Offene Bestellungen </h4>  


<table class="table">
  <tbody>
    <thead>
      <tr>
        <td>
        BesttelungsNR
        </td>
        <td>
        Abholungszeit
        </td>
        <td>
        Abholung Zeit aktualisieren
        </td>
        <td></td>
      </tr>
    </thead>
     
      <?php 
       require 'includes/connection.php';

       $stmt3 = "SELECT * FROM abholung " ;
       $result3 = $con->query($stmt3);
       if($result3->num_rows > 0){

        while( $row = $result3->fetch_assoc()){
          ?>
          <tr> 
            <td> 
              <?php echo $row['BesttelungsNR'];?> 
            </td> 
            <td> 
              <?php echo $row['Abholungszeit'];?> 
            </td> 

      <form action= "includes/abholung.php" method="POST">
  
      
        <td>
        <input type="time" value="Abholungszeit">
        <input type="hidden" name="reset" value="<?php echo $row['BesttelungsNR'];?>">
      </td> 
      <td> <button type="submit" name="reset_timer"> Absenden <button>  </td>
     </form>

    </tr> 
    <?php
                }
                } 
              ?>
  </tbody>
</table>