




<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);



              include('connection.php') ;
             
              

              $stmt = "SELECT * FROM `session` ";
              $result = $con->query($stmt) or die("Bad SQL: $stmt");

            

               $opt = "<td><select name='session'>";
                while( $roww = $result->fetch_assoc()){

               $opt .= "<option value='{$roww['SessionID']}'>{$roww['SessionID']} {$roww['Session']} </option>\n";

                }
               $opt .= "</select></td>";



     

?>





<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);


               if(isset($_POST["Add"])){

               include "./connection.php";
               session_start();

               $sess = $_POST["session"];
               

               $sess = stripslashes($sess);
               
               $sess = mysqli_real_escape_string($con, $sess);

               $stmt = "SELECT * FROM `session`where SessionID = '$sess' ";
               $result = $con->query($stmt);

               if($result->num_rows > 0) { 
            
               $roww2 = $result->fetch_assoc();
               


               $_SESSION['datum'] = $roww2['Datum'];
               $_SESSION['sess'] = $roww2['Session'];
               
          }
          header("Location: ../mitarbeiter.php");

     }


?>